@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Podcasts</div>

                <div class="card-body">
                    <ul class="list-group">
                    @foreach($podcasts as $podcast)
                    <li class="list-group-item">
                        <img src="{{$podcast->image}}" alt="{{$podcast->title}}" width="100" height="100">

                            <span>{{$podcast->title}}</span>
                            <span>{{$podcast->description}}</span>
                    </li>
                    @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
